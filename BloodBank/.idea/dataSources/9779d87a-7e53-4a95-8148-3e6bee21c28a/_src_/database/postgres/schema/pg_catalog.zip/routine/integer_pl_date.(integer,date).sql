CREATE FUNCTION integer_pl_date (integer, date) RETURNS date
	LANGUAGE sql
AS $$
select $2 + $1
$$
